package server;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;


/**
 *
 * @author F. Kasper, ferdinand.kasper@bildung.gv.at
 */
@IntegrationTest
class MainTest {

    @Test
    @Order(10)
    void contextLoads() {
    }

}