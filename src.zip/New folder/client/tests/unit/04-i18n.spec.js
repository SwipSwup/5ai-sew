import Vue from 'vue'
import options, { i18n } from '@/config'

const config = options(Vue)


/**
 * TODO Tests internationalization
 */
describe('I18N', () => {
})
