import Vue from 'vue'
import options from '@/config'
import { emitEventBus, onEventBus } from '@/services/event-bus'

const config = options(Vue)


/**
 * TODO Tests the event bus
 */
describe('Event bus', () => {
})
